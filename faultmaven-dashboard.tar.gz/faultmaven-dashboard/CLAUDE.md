# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Repository Overview

This is the **FaultMaven Dashboard** - a web application for managing knowledge base documents. Built with Next.js 14, React 19, and TypeScript, this dashboard provides a modern interface for uploading, organizing, searching, and editing technical documentation for the FaultMaven AI troubleshooting platform.

**Key Technologies**: Next.js 14, React 19, TypeScript 5.4, Tailwind CSS 3.4

## Common Commands

### Development
```bash
npm install                    # Install dependencies
npm run dev                    # Start development server (http://localhost:3000)
npm run type-check             # TypeScript compilation check
npm run lint                   # Run ESLint
```

### Building and Deployment
```bash
npm run build                  # Production build
npm run start                  # Start production server
```

## Configuration

### Environment Variables
All configuration is done via environment variables:

```bash
# Copy example template
cp .env.example .env.local

# Edit .env.local with your settings
```

**Available Variables:**
- `NEXT_PUBLIC_API_URL` - Backend API endpoint (default: `http://localhost:8000`)

**Important:** All `NEXT_PUBLIC_*` variables are embedded at BUILD TIME and exposed to the browser. Changing them requires:
- Dev mode: Restart `npm run dev`
- Production: Rebuild with `npm run build`

## High-Level Architecture

### Application Structure

```
src/
├── app/                  # Next.js App Router
│   ├── layout.tsx        # Root layout (HTML structure)
│   ├── page.tsx          # Home page (KB management UI)
│   └── globals.css       # Global styles with Tailwind
├── components/           # React components
│   ├── UploadModal.tsx   # Document upload modal
│   ├── DocumentList.tsx  # Document listing with actions
│   ├── DocumentViewer.tsx# Document view/edit modal
│   └── SearchBar.tsx     # Search input component
└── lib/                  # Core logic
    └── api.ts            # FaultMaven API client
```

### Key Patterns

1. **Next.js App Router**: Modern file-based routing with React Server Components
2. **Client Components**: All interactive components use `'use client'` directive
3. **TypeScript Strict Mode**: Strict type checking for reliability
4. **Tailwind CSS**: Utility-first styling for rapid UI development
5. **API Integration**: RESTful communication with FaultMaven backend
6. **Dual Scope Management**: Both personal (user) and global (team) knowledge bases
7. **Error Boundaries**: Comprehensive error handling throughout

### API Integration

The dashboard communicates with the FaultMaven backend:

**Global Knowledge Base:**
- `uploadKnowledgeDocument()`, `getKnowledgeDocuments()`, `getKnowledgeDocument()`
- `updateKnowledgeDocument()`, `deleteKnowledgeDocument()`, `searchKnowledgeBase()`

**User Knowledge Base:**
- `uploadUserKnowledgeDocument()`, `getUserKnowledgeDocuments()`
- `updateUserKnowledgeDocument()`, `deleteUserKnowledgeDocument()`, `searchUserKnowledgeBase()`

**Capabilities:**
- `getCapabilities()` - Fetch backend deployment mode and features

**API Endpoint Configuration:**
- Set via `NEXT_PUBLIC_API_URL` environment variable
- Self-hosted: `http://localhost:8000`
- Enterprise: `https://api.faultmaven.ai`

### Application Flow

1. **Home Page Load**: Fetches user or global KB documents based on active tab
2. **Upload Flow**: User uploads document → API call → Refresh list
3. **Search Flow**: User types query → API search → Display results
4. **Edit Flow**: Click document → View modal → Edit mode → Save → Update list
5. **Delete Flow**: Click delete → Confirm → API delete → Refresh list
6. **Scope Switch**: Toggle between Personal KB and Global KB tabs

### Component Architecture

- **HomePage** (`app/page.tsx`): Main application container, manages state and orchestrates components
- **UploadModal**: Modal dialog for uploading new documents with file upload or manual entry
- **DocumentList**: Grid display of documents with metadata, tags, and delete actions
- **DocumentViewer**: Modal for viewing and editing document details
- **SearchBar**: Search input with submit and clear functionality

## Development Guidelines

### Backend Dependency

The dashboard requires the FaultMaven backend running and accessible:
- Self-hosted: `http://localhost:8000`
- Enterprise: `https://api.faultmaven.ai`

Set the backend URL in `.env.local` before starting development.

### Code Patterns

- **Path Aliases**: Use `@/*` for `src/*` imports
- **TypeScript Strict**: All code must pass strict type checking
- **Error Handling**: Comprehensive try-catch with user-friendly messages
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Accessibility**: ARIA labels, keyboard navigation, screen reader support

### API Development

When working with backend integration:
- All API functions include proper error handling with `APIError` class
- Response types are strictly typed with TypeScript interfaces
- API calls are made from client components using React hooks
- Loading and error states are managed locally in components

**Important Files:**
- `src/lib/api.ts` - API client with all backend communication
- `src/app/page.tsx` - Main application logic and state management

### Styling Guidelines

- Use Tailwind utility classes for styling
- Follow mobile-first responsive design
- Use consistent spacing scale (p-4, p-6, etc.)
- Maintain color palette from `tailwind.config.js`
- Dark mode support via Tailwind's dark mode utilities

### Component Development

- Use TypeScript for all components with explicit prop interfaces
- Include proper accessibility attributes (aria-label, etc.)
- Implement loading states for async operations
- Provide user feedback for all actions (success/error messages)
- Use controlled components for form inputs

## Deployment

### Environment-Specific Configuration

**Development:**
```env
NEXT_PUBLIC_API_URL=http://localhost:8000
```

**Production:**
```env
NEXT_PUBLIC_API_URL=https://api.faultmaven.ai
```

### Deployment Platforms

- **Vercel**: Recommended, automatic deployments from git
- **Docker**: Containerized deployment for self-hosting
- **Static Export**: Build and deploy to any CDN/static host

## Architecture Decisions

### Why Next.js?
- Server-side rendering for better SEO and performance
- File-based routing for simple navigation
- Built-in optimizations (images, fonts, etc.)
- Great developer experience with fast refresh

### Why React 19?
- Latest features and improvements
- Better performance with concurrent rendering
- Improved TypeScript integration

### Why Tailwind CSS?
- Rapid UI development without custom CSS
- Consistent design system
- Small production bundle with purging
- Easy responsive design

### Why TypeScript?
- Type safety catches bugs early
- Better IDE support and autocompletion
- Self-documenting code with interfaces
- Safer refactoring

## Relationship to FaultMaven Copilot

This dashboard is part of the **universal split architecture** for FaultMaven:

- **FaultMaven Copilot** (browser extension): Chat-only interface for troubleshooting
- **FaultMaven Dashboard** (this project): Web app for KB management

**Key Integration Points:**
1. Extension detects backend via `/v1/meta/capabilities` API
2. Backend returns `dashboardUrl` in capabilities response
3. Extension displays "KB Dashboard" button that opens this web app
4. Both extension and dashboard use same backend API
5. Both support self-hosted and enterprise deployments

This architecture provides:
- Smaller extension bundle size (~400KB reduction)
- Richer KB management UX in web app
- Consistent experience across deployment modes
- Single codebase for both self-hosted and enterprise

      IMPORTANT: this context may or may not be relevant to your tasks. You should not respond to this context unless it is highly relevant to your task.
