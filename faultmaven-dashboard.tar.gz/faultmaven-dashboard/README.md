# FaultMaven Dashboard

![Version](https://img.shields.io/badge/version-0.1.0-blue.svg)
![Next.js](https://img.shields.io/badge/Next.js-14.2-black.svg)
![React](https://img.shields.io/badge/React-19-blue.svg)
![TypeScript](https://img.shields.io/badge/TypeScript-5.4-blue.svg)

**Knowledge Base Management Dashboard for FaultMaven AI**

A modern, responsive web application for managing FaultMaven knowledge base documents. This dashboard provides a user-friendly interface for uploading, searching, editing, and organizing technical documentation, runbooks, incident reports, and other knowledge resources.

## Features

### Knowledge Base Management
- **Document Upload**: Upload documents from files (.txt, .md, .log, .json, .csv) or paste content directly
- **Document Organization**: Categorize documents and add tags for easy organization
- **Full-Text Search**: Search across all documents by title, content, or tags
- **Document Editing**: View and edit document content, metadata, tags, and categories
- **Dual Scope Support**: Manage both personal (user) and global (team) knowledge bases

### User Experience
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile devices
- **Modern UI**: Clean, professional interface built with Tailwind CSS
- **Real-time Updates**: Immediate feedback for all operations
- **Error Handling**: Comprehensive error messages and recovery options

## Technology Stack

- **Framework**: Next.js 14 (App Router)
- **UI Library**: React 19
- **Language**: TypeScript 5.4
- **Styling**: Tailwind CSS 3.4
- **Build Tool**: Turbopack (Next.js built-in)

## Prerequisites

- Node.js >= 18.0.0
- npm or pnpm package manager
- FaultMaven backend running and accessible

## Installation

1. **Clone the repository**:
   ```bash
   git clone https://github.com/sterlanyu/faultmaven-dashboard.git
   cd faultmaven-dashboard
   ```

2. **Install dependencies**:
   ```bash
   npm install
   # or
   pnpm install
   ```

3. **Configure environment**:
   ```bash
   cp .env.example .env.local
   ```

   Edit `.env.local` with your settings:
   ```env
   # Self-hosted backend
   NEXT_PUBLIC_API_URL=http://localhost:8000

   # Enterprise backend
   # NEXT_PUBLIC_API_URL=https://api.faultmaven.ai
   ```

## Development

Start the development server:

```bash
npm run dev
# or
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

The application will automatically reload when you make changes to the source code.

## Building for Production

Build the application for production:

```bash
npm run build
npm run start
# or
pnpm build
pnpm start
```

The production build is optimized for performance and security.

## Project Structure

```
faultmaven-dashboard/
├── src/
│   ├── app/              # Next.js app router pages
│   │   ├── layout.tsx    # Root layout
│   │   ├── page.tsx      # Home page (KB management)
│   │   └── globals.css   # Global styles
│   ├── components/       # React components
│   │   ├── UploadModal.tsx     # Document upload
│   │   ├── DocumentList.tsx    # Document listing
│   │   ├── DocumentViewer.tsx  # Document view/edit
│   │   └── SearchBar.tsx       # Search interface
│   └── lib/              # Core logic
│       └── api.ts        # FaultMaven API client
├── public/               # Static assets
├── .env.example          # Environment template
├── next.config.js        # Next.js configuration
├── tailwind.config.js    # Tailwind CSS config
├── tsconfig.json         # TypeScript config
└── package.json          # Dependencies
```

## API Integration

The dashboard communicates with the FaultMaven backend through RESTful APIs:

### Global Knowledge Base
- `POST /api/v1/knowledge/documents` - Upload document
- `GET /api/v1/knowledge/documents` - List all documents
- `GET /api/v1/knowledge/documents/:id` - Get single document
- `PATCH /api/v1/knowledge/documents/:id` - Update document
- `DELETE /api/v1/knowledge/documents/:id` - Delete document
- `GET /api/v1/knowledge/search` - Search documents

### User Knowledge Base
- `POST /api/v1/users/me/knowledge/documents` - Upload personal document
- `GET /api/v1/users/me/knowledge/documents` - List personal documents
- `PATCH /api/v1/users/me/knowledge/documents/:id` - Update personal document
- `DELETE /api/v1/users/me/knowledge/documents/:id` - Delete personal document
- `GET /api/v1/users/me/knowledge/search` - Search personal documents

### Capabilities
- `GET /v1/meta/capabilities` - Get backend capabilities and configuration

## Configuration

### Environment Variables

All configuration is done via environment variables in `.env.local`:

| Variable | Description | Default |
|----------|-------------|---------|
| `NEXT_PUBLIC_API_URL` | Backend API endpoint | `http://localhost:8000` |

**Note**: All `NEXT_PUBLIC_*` variables are exposed to the browser and embedded at build time.

### API Endpoint Setup

**Self-Hosted Backend**:
```env
NEXT_PUBLIC_API_URL=http://localhost:8000
```

**Enterprise Backend**:
```env
NEXT_PUBLIC_API_URL=https://api.faultmaven.ai
```

## Deployment

### Vercel (Recommended)

1. Push your code to GitHub
2. Import the repository in Vercel
3. Configure environment variables in Vercel dashboard
4. Deploy

### Docker

```bash
# Build Docker image
docker build -t faultmaven-dashboard .

# Run container
docker run -p 3000:3000 -e NEXT_PUBLIC_API_URL=http://localhost:8000 faultmaven-dashboard
```

### Static Export

For static hosting (CDN, S3, etc.):

```bash
npm run build
# Upload the .next/out directory to your hosting provider
```

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Security

- **API Authentication**: All API calls include proper authentication headers
- **Input Validation**: Client-side validation for all user inputs
- **XSS Protection**: React's built-in XSS protection
- **CORS**: Configured for cross-origin requests
- **Content Security Policy**: Strict CSP headers in production

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Commit your changes: `git commit -m 'Add my feature'`
4. Push to the branch: `git push origin feature/my-feature`
5. Open a pull request

## License

This project is part of the FaultMaven ecosystem. See the main FaultMaven repository for license information.

## Support

For issues, questions, or contributions:
- GitHub Issues: https://github.com/sterlanyu/faultmaven-dashboard/issues
- FaultMaven Documentation: https://docs.faultmaven.ai

## Related Projects

- **FaultMaven Copilot**: Browser extension for in-context troubleshooting
- **FaultMaven Backend**: AI-powered troubleshooting API
- **FaultMaven CLI**: Command-line interface for FaultMaven

---

**Version**: 0.1.0
**Last Updated**: 2025-11-15
