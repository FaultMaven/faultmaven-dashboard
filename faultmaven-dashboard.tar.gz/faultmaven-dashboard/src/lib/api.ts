/**
 * FaultMaven API Client for Dashboard
 * Handles all backend communication for KB management
 */

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

// ===== Type Definitions =====

export interface KnowledgeDocument {
  id: string;
  title: string;
  content: string;
  metadata: {
    source?: string;
    tags?: string[];
    category?: string;
    [key: string]: any;
  };
  created_at: string;
  updated_at: string;
  owner_id?: string;
}

export interface UploadKnowledgeDocumentRequest {
  title: string;
  content: string;
  metadata?: {
    source?: string;
    tags?: string[];
    category?: string;
    [key: string]: any;
  };
}

export interface SearchKnowledgeRequest {
  query: string;
  limit?: number;
  filters?: {
    tags?: string[];
    category?: string;
    [key: string]: any;
  };
}

export interface BackendCapabilities {
  deploymentMode: 'self-hosted' | 'enterprise';
  kbManagement: 'dashboard';
  dashboardUrl: string;
  features: {
    extensionKB: boolean;
    adminKB: boolean;
    teamWorkspaces: boolean;
    caseHistory: boolean;
    sso: boolean;
  };
  limits: {
    maxFileBytes: number;
    allowedExtensions: string[];
    maxDocuments?: number;
  };
  branding?: {
    name: string;
    logoUrl?: string;
    supportUrl?: string;
  };
}

// ===== Error Handling =====

export class APIError extends Error {
  constructor(
    message: string,
    public status?: number,
    public response?: any
  ) {
    super(message);
    this.name = 'APIError';
  }
}

async function handleResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const errorText = await response.text();
    let errorMessage = `API request failed: ${response.status}`;

    try {
      const errorData = JSON.parse(errorText);
      errorMessage = errorData.detail || errorData.message || errorMessage;
    } catch {
      errorMessage = errorText || errorMessage;
    }

    throw new APIError(errorMessage, response.status, errorText);
  }

  const contentType = response.headers.get('content-type');
  if (contentType && contentType.includes('application/json')) {
    return response.json();
  }

  return response.text() as any;
}

// ===== Capabilities =====

export async function getCapabilities(): Promise<BackendCapabilities> {
  const response = await fetch(`${API_URL}/v1/meta/capabilities`, {
    method: 'GET',
    headers: {
      'Accept': 'application/json',
    },
  });

  return handleResponse<BackendCapabilities>(response);
}

// ===== Knowledge Base Management =====

/**
 * Upload a new knowledge document
 */
export async function uploadKnowledgeDocument(
  data: UploadKnowledgeDocumentRequest
): Promise<KnowledgeDocument> {
  const response = await fetch(`${API_URL}/api/v1/knowledge/documents`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });

  return handleResponse<KnowledgeDocument>(response);
}

/**
 * Get all knowledge documents
 */
export async function getKnowledgeDocuments(): Promise<KnowledgeDocument[]> {
  const response = await fetch(`${API_URL}/api/v1/knowledge/documents`, {
    method: 'GET',
    headers: {
      'Accept': 'application/json',
    },
  });

  return handleResponse<KnowledgeDocument[]>(response);
}

/**
 * Get a single knowledge document by ID
 */
export async function getKnowledgeDocument(documentId: string): Promise<KnowledgeDocument> {
  const response = await fetch(`${API_URL}/api/v1/knowledge/documents/${documentId}`, {
    method: 'GET',
    headers: {
      'Accept': 'application/json',
    },
  });

  return handleResponse<KnowledgeDocument>(response);
}

/**
 * Update a knowledge document
 */
export async function updateKnowledgeDocument(
  documentId: string,
  updates: Partial<UploadKnowledgeDocumentRequest>
): Promise<KnowledgeDocument> {
  const response = await fetch(`${API_URL}/api/v1/knowledge/documents/${documentId}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(updates),
  });

  return handleResponse<KnowledgeDocument>(response);
}

/**
 * Delete a knowledge document
 */
export async function deleteKnowledgeDocument(documentId: string): Promise<void> {
  const response = await fetch(`${API_URL}/api/v1/knowledge/documents/${documentId}`, {
    method: 'DELETE',
  });

  if (!response.ok) {
    throw new APIError(`Failed to delete document: ${response.status}`, response.status);
  }
}

/**
 * Search knowledge base
 */
export async function searchKnowledgeBase(params: SearchKnowledgeRequest): Promise<KnowledgeDocument[]> {
  const queryParams = new URLSearchParams();
  queryParams.append('q', params.query);

  if (params.limit) {
    queryParams.append('limit', params.limit.toString());
  }

  if (params.filters) {
    queryParams.append('filters', JSON.stringify(params.filters));
  }

  const response = await fetch(`${API_URL}/api/v1/knowledge/search?${queryParams}`, {
    method: 'GET',
    headers: {
      'Accept': 'application/json',
    },
  });

  return handleResponse<KnowledgeDocument[]>(response);
}

// ===== User-Scoped Knowledge Base =====

/**
 * Upload document to user's personal KB
 */
export async function uploadUserKnowledgeDocument(
  data: UploadKnowledgeDocumentRequest
): Promise<KnowledgeDocument> {
  const response = await fetch(`${API_URL}/api/v1/users/me/knowledge/documents`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });

  return handleResponse<KnowledgeDocument>(response);
}

/**
 * Get all documents from user's personal KB
 */
export async function getUserKnowledgeDocuments(): Promise<KnowledgeDocument[]> {
  const response = await fetch(`${API_URL}/api/v1/users/me/knowledge/documents`, {
    method: 'GET',
    headers: {
      'Accept': 'application/json',
    },
  });

  return handleResponse<KnowledgeDocument[]>(response);
}

/**
 * Update document in user's personal KB
 */
export async function updateUserKnowledgeDocument(
  documentId: string,
  updates: Partial<UploadKnowledgeDocumentRequest>
): Promise<KnowledgeDocument> {
  const response = await fetch(`${API_URL}/api/v1/users/me/knowledge/documents/${documentId}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(updates),
  });

  return handleResponse<KnowledgeDocument>(response);
}

/**
 * Delete document from user's personal KB
 */
export async function deleteUserKnowledgeDocument(documentId: string): Promise<void> {
  const response = await fetch(`${API_URL}/api/v1/users/me/knowledge/documents/${documentId}`, {
    method: 'DELETE',
  });

  if (!response.ok) {
    throw new APIError(`Failed to delete user document: ${response.status}`, response.status);
  }
}

/**
 * Search user's personal KB
 */
export async function searchUserKnowledgeBase(params: SearchKnowledgeRequest): Promise<KnowledgeDocument[]> {
  const queryParams = new URLSearchParams();
  queryParams.append('q', params.query);

  if (params.limit) {
    queryParams.append('limit', params.limit.toString());
  }

  if (params.filters) {
    queryParams.append('filters', JSON.stringify(params.filters));
  }

  const response = await fetch(`${API_URL}/api/v1/users/me/knowledge/search?${queryParams}`, {
    method: 'GET',
    headers: {
      'Accept': 'application/json',
    },
  });

  return handleResponse<KnowledgeDocument[]>(response);
}
