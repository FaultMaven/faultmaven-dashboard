'use client';

import { useState } from 'react';
import type { KnowledgeDocument } from '@/lib/api';
import { deleteKnowledgeDocument, deleteUserKnowledgeDocument } from '@/lib/api';

interface DocumentListProps {
  documents: KnowledgeDocument[];
  onDocumentClick: (doc: KnowledgeDocument) => void;
  onRefresh: () => void;
  scope: 'global' | 'user';
}

export function DocumentList({ documents, onDocumentClick, onRefresh, scope }: DocumentListProps) {
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const handleDelete = async (e: React.MouseEvent, docId: string) => {
    e.stopPropagation();

    if (!confirm('Are you sure you want to delete this document? This action cannot be undone.')) {
      return;
    }

    setDeletingId(docId);
    try {
      if (scope === 'user') {
        await deleteUserKnowledgeDocument(docId);
      } else {
        await deleteKnowledgeDocument(docId);
      }
      onRefresh();
    } catch (error: any) {
      alert(`Failed to delete document: ${error.message}`);
    } finally {
      setDeletingId(null);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (documents.length === 0) {
    return (
      <div className="text-center py-12">
        <svg
          className="w-16 h-16 text-gray-300 mx-auto mb-4"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
          />
        </svg>
        <h3 className="text-lg font-medium text-gray-900 mb-2">No documents yet</h3>
        <p className="text-gray-600">Upload your first document to get started</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {documents.map((doc) => (
        <div
          key={doc.id}
          onClick={() => onDocumentClick(doc)}
          className="bg-white border border-gray-200 rounded-lg p-4 hover:border-blue-500 hover:shadow-md transition-all cursor-pointer"
        >
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-lg font-semibold text-gray-900 flex-1">{doc.title}</h3>
            <button
              onClick={(e) => handleDelete(e, doc.id)}
              disabled={deletingId === doc.id}
              className="ml-4 text-red-600 hover:text-red-800 disabled:opacity-50"
              aria-label="Delete document"
            >
              {deletingId === doc.id ? (
                <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
              ) : (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
              )}
            </button>
          </div>

          <p className="text-gray-600 text-sm mb-3 line-clamp-2">
            {doc.content.substring(0, 200)}...
          </p>

          <div className="flex flex-wrap gap-2 items-center text-sm">
            {doc.metadata.category && (
              <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium">
                {doc.metadata.category}
              </span>
            )}

            {doc.metadata.tags && doc.metadata.tags.map((tag) => (
              <span
                key={tag}
                className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs"
              >
                #{tag}
              </span>
            ))}

            <span className="ml-auto text-gray-500 text-xs">
              Updated: {formatDate(doc.updated_at)}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}
